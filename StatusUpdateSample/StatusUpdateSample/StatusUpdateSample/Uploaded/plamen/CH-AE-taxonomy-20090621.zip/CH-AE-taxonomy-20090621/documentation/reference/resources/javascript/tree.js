/*--------------------------------------------------|
| xTree 1.0 | xbrl.galexy.net/js/xTree/xTree.js     |
|---------------------------------------------------|
| Copyright (c) 2005 Geoff Shuetrim                 |
|                                                   |
| This script can be used freely as long as all     |
| copyright messages are intact.                    |
|                                                   |
| Adapted heavily from the dTree.js by Geir Landr?  |
| Paul Wallace of Decisionsoft also contributed.    |
| Updated: 12.05.2005                               |
|--------------------------------------------------*/


/*--------------------------------------------------|
| dTree 2.05 | www.destroydrop.com/javascript/tree/ |
|---------------------------------------------------|
| Copyright (c) 2002-2003 Geir Landr?               |
|                                                   |
| This script can be used freely as long as all     |
| copyright messages are intact.                    |
|                                                   |
| Updated: 17.04.2003                               |
|--------------------------------------------------*/

// Node object
function Node(id, pid, name, url, title, target, icon, iconOpen, open, diffStatus, childModified) {
	// the diff status of this node, one of 'unchanged', 'added', 'removed', 'conceptModified'.
	this.diffStatus = diffStatus;

	// false iff one or more of its descendants are not 'unchanged'
	this.childModified = childModified;

	//Unique id of the node itself
	this.id = id;

	// id of the parent node
	this.pid = pid;

	// Text label for this node
	if (name)
		this.name = this.unescape(name);
	else
		this.name = name;

	// URL for the hyperlink from this node
	this.url = url;

	// Title (pop-up) text for this node
	this.title = title;

	// The target for the hyperlink from this node (new window etc)
	this.target = target;

	// The icon to use for this node when it is closed or a leaf node
	this.icon = icon;

	// The icon to use for this node when it is open
	this.iconOpen = iconOpen;

	// Array of child nodes
	this.cNodes = [];

	// Indentation information (This needs more work)
	this.indent = 0;

	// True if has children
	this.hasChildren = false;

	// True if is open (always true for the root)
	this.isOpen = open || false;

	// True if the node is the last of the siblings
	this.lastSibling = false;

	// Initialise the root node
	if (this.id == -1) {
		this.hasChildren = true;
		this.isOpen = true;
		this.lastSibling = true;
	}

};

Node.prototype.unescape = function(text) {
	text = text.replace(/&amp;/ig,"&");
	text.replace(/&lt;/ig,"<");
	text.replace(/&gt;/ig,">");
	return text;
};

// Tree object
function xTree(objName, resourceRoot) {

	// target is the target for hyperlinks from nodes in the tree
	// folderLinks is a switch controlling whether non-leaf nodes can link
	// useSelection is a switch controlling whether nodes in the tree can be selected
	// useCookies controls whether cookies are used to store the state of the tree
	// useLines controls whether lines are drawn for the tree
	// useIcons controls whether icons are shown for the tree nodes
	// useStatusText controls whether the selected node is reflected in the status bar
	// closeSameLevel controls whether ????
	this.config = {
		target		: null,
		folderLinks	: true,
		useSelection	: true,
		useCookies	: true,
		useLines	: true,
		useIcons	: true,
		useStatusText	: true,
		closeSameLevel	: false
	};

	// Declares the icons to use for the tree
	this.icon = {
		root		: resourceRoot + 'img/xtree/base.gif',
		folder		: resourceRoot + 'img/xtree/folder.gif',
		folderOpen	: resourceRoot + 'img/xtree/folderopen.gif',
		node		: resourceRoot + 'img/xtree/page.gif',
		empty		: resourceRoot + 'img/xtree/empty.gif',
		line		: resourceRoot + 'img/xtree/line.gif',
		join		: resourceRoot + 'img/xtree/join.gif',
		joinBottom	: resourceRoot + 'img/xtree/joinbottom.gif',
		plus		: resourceRoot + 'img/xtree/plus.gif',
		plusBottom	: resourceRoot + 'img/xtree/plusbottom.gif',
		minus		: resourceRoot + 'img/xtree/minus.gif',
		minusBottom	: resourceRoot + 'img/xtree/minusbottom.gif',
		nlPlus		: resourceRoot + 'img/xtree/nolines_plus.gif',
		nlMinus		: resourceRoot + 'img/xtree/nolines_minus.gif',
		abstractC	: resourceRoot + 'img/xtree/icon_a5.png',
		tuple		: resourceRoot + 'img/xtree/icon_t6.png',
		instant		: resourceRoot + 'img/xtree/icon_i5.png',
		duration	: resourceRoot + 'img/xtree/icon_d5.png',
		concrete	: resourceRoot + 'img/xtree/concrete.gif',
		network		: resourceRoot + 'img/xtree/network.png',
		empty		: resourceRoot + 'img/xtree/empty.gif',
		added		: resourceRoot + 'img/xtree/add3.png',
		deleted		: resourceRoot + 'img/xtree/del3.png',
		modified	: resourceRoot + 'img/xtree/edit3.png'
	};

	// The root HTML element for the tree itself
  	this.tree = document.getElementById("xTree");

	// The current insertion point element in the tree
  	this.current = this.tree;

	// The string name of this tree object
	this.obj = objName;

	// The hashtable of nodes in the tree
	this.hNodes = {};

	// The list of selected nodes in the tree
	this.sNodes = [];

	// An array used to store the indentation images to use
	this.aIndent = [];

	// The root node in the tree, which is initialised to being open.
	this.root = new Node(-1);

	// Set to true when an tree node is clicked, to generate a new detail page
	// Set back to false by the detail page when it has finished loading
	// Used to ensure that the tree is not forced to synchronise when the tree itself
	// has caused a change in the body of the page.
	this.synchronised = false;

	// Set to true when the tree has been initialised
	this.completed = false;
};

// Adds a node with default target of 'concept_area' and no title.
xTree.prototype.add2 = function(id, pid, name, url, icon, open, diffStatus, childModified) {
	this.add(id, pid, name, url, '', 'concept_area', icon, icon, open, diffStatus, childModified);
}

// Finished
// Adds a new node to the node hashtable and
// records it in its parent node array of child nodes.
xTree.prototype.add = function(id, pid, name, url, title, target, icon, iconOpen, open, diffStatus, childModified) {
	this.hNodes[id] = new Node(id, pid, name, url, title, target, icon, iconOpen, open, diffStatus, childModified);
	if (pid != -1) {
		var pNode = this.hNodes[pid];
		pNode.cNodes[pNode.cNodes.length] = this.hNodes[id];
		if (diffStatus == "added" || diffStatus == "conceptModified" || diffStatus == "removed" || childModified == "true") {
			this.setDescendantModified(pid);
		}
	} else {
		this.root.cNodes[this.root.cNodes.length] = this.hNodes[id];
	}
};

// Sets a given node as descendant modified, recursing upwards as far as necessary.
xTree.prototype.setDescendantModified = function(id) {
	var node = this.hNodes[id];
	if (id != -1 && node.childModified != "true") {
		node.childModified = "true";
		this.setDescendantModified(node.pid);
	}
}

// Initialise the nodes in the tree based on the state stored in the cookie
xTree.prototype.initialise = function() {

	if (document.getElementById) {

		if (this.config.useCookies)
			this.setSelectedNodes();

		this.initialiseChildren(this.root);

	} else {
		document.write('Browser not supported.');
	}

};

// Initialises the child nodes of the specified node
xTree.prototype.initialiseChildren = function(pNode) {
	var cn;
	for (var i=0; i<pNode.cNodes.length; i++) {

		cn = pNode.cNodes[i];

		if (cn.cNodes.length > 0)
			cn.hasChildren = true;
		else
			cn.hasChildren = false;

		cn.lastSibling = false;

		if (!cn.target && this.config.target)
			cn.target = this.config.target;

		// Check if the node was marked as open in the cookie
		if (cn.hasChildren && !cn.isOpen && this.config.useCookies)
			cn.isOpen = this.isOpen(cn.id);

		// If the non-leaf nodes do not hyperlink, make sure URL is null
		if (!this.config.folderLinks && cn.hasChildren)
			cn.url = null;

		// If the node is selected, then track this in the selected nodes array
		// This is redundant - the operation is done earlier in the initialisation!
		//if (this.config.useSelection && this.isSelected(cn.id))
		//	this.sNodes[this.sNodes.length] = cn.id;

		this.initialiseChildren(cn);
	}
	if (pNode.cNodes.length > 0)
		pNode.cNodes[pNode.cNodes.length-1].lastSibling = true;
};

// Generates the string representation of the tree in HTML
xTree.prototype.display = function() {

	if (document.getElementById)
		this.addChildren(this.root);
	else
		document.write('Browser not supported.');

	this.completed = true;
};

// Add the children of the open node to the HTML tree output
xTree.prototype.addChildren = function(pNode) {

	// Only add children if the node has them
	// TODO Check if this is redundant given the loop boundaries below
	if (pNode.hasChildren == false)
		return;

	for (var i=0; i<pNode.cNodes.length; i++) {
			var cn = pNode.cNodes[i];
			this.nodeHTML(cn);
			if (cn.lastSibling) break;
	}
};

// Creates the node icon, url and text and then do so for displayed descendants
xTree.prototype.nodeHTML = function(node) {

	// Create the container div element
	var container = document.createElement("div");
	container.className = "xTreeNode";
	this.current.appendChild(container);
	this.current = container;

	// Add the indentation lines and spaces and controls
	if (node.pid != -1) {
		this.getIndentFromParent(this.hNodes[node.pid]);

		// Add the expand/collapse control
		if (node.hasChildren) {
			var anchor = document.createElement("a");
			anchor.href="javascript: " + this.obj + ".toggleStatus('" + node.id + "');";
			this.current.appendChild(anchor);
			var join = document.createElement("img");
			join.id = "j" + this.obj + node.id;
			if (!this.config.useLines)
				(node.isOpen) ? join.src = this.icon.nlMinus : join.src = this.icon.nlPlus;
			else
				( (node.isOpen) ? ((node.lastSibling && this.config.useLines) ? join.src = this.icon.minusBottom : join.src = this.icon.minus) : ((node.lastSibling && this.config.useLines) ? join.src = this.icon.plusBottom : join.src = this.icon.plus ) );
			anchor.appendChild(join);
			//join.alt = "";
		} else {
			var join = document.createElement("img");
			//join.alt = "";
			this.current.appendChild(join);
			( (this.config.useLines) ? ((node.lastSibling) ? join.src = this.icon.joinBottom : join.src = this.icon.join ) : join.src = this.icon.empty);
		}

	}

	// Create the appropriate icon for the node
	if (this.config.useIcons) {
		var container = document.createElement("a");
		container.className = "xtree";

		container.href="javascript: " + this.obj + ".collapseToChildren(\"" + node.id + "\");"
		this.current.appendChild(container);

		if (!node.icon)
			node.icon = (this.root.id == node.pid) ? this.icon.root : ((node.hasChildren) ? this.icon.folder : this.icon.node);
		if (!node.iconOpen)
			node.iconOpen = (node.hasChildren) ? this.icon.folderOpen : this.icon.node;
		if (this.root.id == node.pid) {
			node.icon = this.icon.root;
			node.iconOpen = this.icon.root;
		}

		var icon = document.createElement("img");
		icon.id = "i" + this.obj + node.id;
		((node.isOpen) ? icon.src = node.iconOpen : icon.src = node.icon);
		container.appendChild(icon);
	}


	if (node.hasChildren) {
		// Generate a branch expander control
		var expander = document.createElement("a");
		expander.href="javascript: " + this.obj + ".openDescendants(\"" + node.id + "\");"
		this.current.appendChild(expander);
		var expanderChar = document.createTextNode("<");
		expander.appendChild(expanderChar);
	}

	// Create the hyperlink to the URL for the node
	if (node.url) {
		var anchor = document.createElement("a");
		anchor.id = "s" + this.obj + node.id;

		if (this.config.useSelection && this.isSelected(node.id))
			anchor.className = 'nodeSel ' + ((node.childModified == 'true' && node.hasChildren && !node.isOpen && node.diffStatus != 'removed') ? 'childModified ' : '') + node.diffStatus;
		else
			anchor.className = 'node ' + ((node.childModified == 'true' && node.hasChildren && !node.isOpen && node.diffStatus != 'removed') ? 'childModified ' : '') + node.diffStatus;

		anchor.href = node.url;

		if (node.title)
			anchor.title = node.title;

		if (node.target)
			anchor.target = node.target;

		//if (this.config.useStatusText) {
		//	anchor.setAttribute("onmouseover","window.top.status='" + node.name + "';return true;");
		//	anchor.setAttribute("onmouseout","window.top.status='';return true;");
		//	anchor.onmouseover = "window.top.status='" + node.name + "';return true;";
		//	anchor.onmouseout = "window.top.status='';return true;";
		//}

		// If using selection and the node either is a leaf node or a folder node
		// where folder nodes are allowed to hyperlink...
		if (this.config.useSelection &&
                    ((node.hasChildren && this.config.folderLinks) || !node.hasChildren)
                   ) {
        		anchor.setAttribute("onClick", this.obj + ".s(\"" + node.id + "\",event);");
			if (navigator.appName == "Microsoft Internet Explorer")
				anchor.onclick = function() {d.s(node.id,event);};
		}

		this.current.appendChild(anchor);
		var nameNode = document.createTextNode(node.name);
		anchor.appendChild(nameNode);
	} else if ((!this.config.folderLinks || !node.url) && node.hasChildren && node.pid != this.root.id) {
		var anchor = document.createElement("a");
		anchor.id = "s" + this.obj + node.id;
		anchor.className = "node " + ((node.childModified == 'true' && node.hasChildren && !node.isOpen && node.diffStatus != 'removed') ? 'childModified ' : '') + node.diffStatus;
		anchor.href = "javascript: " + this.obj + ".toggleStatus('" + node.id + "');";
		this.current.appendChild(anchor);
		var nameNode = document.createTextNode(node.name);
		anchor.appendChild(nameNode);
	} else {
		var span = document.createElement("span");
		span.setAttribute("class", ((node.childModified == 'true' && node.hasChildren && !node.isOpen && node.diffStatus != 'removed') ? 'childModified ' : '') + node.diffStatus);  // Set appropriate styling for diffed nodes.
		this.current.appendChild(span);
		var nameNode = document.createTextNode(node.name);
		span.appendChild(nameNode);
	}
	// Adds the relevant status icon.
	if (node.diffStatus == "added" || node.diffStatus == "removed" || node.diffStatus == "conceptModified") {
		var image = document.createElement("img");
		image.id = "statusIcon" + this.obj + node.id;
		if (node.diffStatus == "added") {
			image.setAttribute("src", this.icon.added);
		}
		else if (node.diffStatus == "removed") {
			image.setAttribute("src", this.icon.deleted);
		}
		else {
			image.setAttribute("src", this.icon.modified);
		}
		this.current.appendChild(image);
	}

	// Handle the children of the node (create the 'eDiv' element to contain them)
	var children = document.createElement("div");
	children.id = "d" + this.obj + node.id;
	children.className = "clip";
	this.current.appendChild(children);
	var current = this.current;
	this.current = children;
	if (node.hasChildren && (node.isOpen || node.pid==-1)) {
		this.addChildren(node);
	}
	this.current = current;

	// Update the indentation information
	this.aIndent.pop();
};

// Finished
// Generate the indentation image for the parent
xTree.prototype.getIndentFromParent = function(node) {

	if (node.id == -1 || node.pid == -1)
		return;

	this.getIndentFromParent(this.hNodes[node.pid]);
	var img = document.createElement("img");
	if (!node.lastSibling && this.config.useLines)
		img.src = this.icon.line
	else
		img.src = this.icon.empty;
	this.current.appendChild(img);
}

// Adds the empty and line icons
// node is the node that the indent is being generated for and the nodeId is the
// id of the node that the indent is being generated for.
xTree.prototype.indent = function(node) {

	// Generate no indent for the root node
	if (this.root.id != node.pid) {

		// Iterate the indentation array in the tree object generating the necessary jpeg image sequences


		// If the node is the last sibling, push a zero onto the indent array, otherwise push a one
		//(node.lastSibling) ? this.aIndent.push(0) : this.aIndent.push(1);

	}
};

// Selects the identified node
xTree.prototype.s = function(id,event) {

	// Handle IE differences
	if (!event)
		event = window.event;

	var target;
	if (event.srcElement) target = event.srcElement;
	else if (event.target) target = event.target;

	// Only select nodes if we are using selection on this tree
	if (!this.config.useSelection)
		return;

	// get the node that has been operated on
	var cn = this.hNodes[id];

	// You can only select hyperlinks
	if (cn.hasChildren && !this.config.folderLinks) return;

	// Clear all previously selected nodes
	this.deselectAllNodes();

	// Select the node
	this.selectNode(cn.id);

	// Indicate that synchronisation of the tree is not needed.
	this.synchronised = true;

};

// Select the node, updating HTML styling and the selected Nodes array: sNodes
// Also update the cookie
xTree.prototype.selectNode = function(nodeId) {
	var node = this.hNodes[nodeId];
  	eNew = document.getElementById("s" + this.obj + nodeId);
	eNew.className = "nodeSel " + ((node.childModified == 'true' && node.hasChildren && !node.isOpen && node.diffStatus != 'removed') ? 'childModified ' : '') + this.hNodes[nodeId].diffStatus;
  	this.sNodes[this.sNodes.length] = nodeId;
	if (this.config.useCookies) this.storeSelectedNodes();
}

// Finished
// Open the specified node and all of its descendants
xTree.prototype.openDescendants = function(rootId) {

	// Start with opening the root node if necessary
	if (!this.hNodes[rootId].isOpen) {
		this.toggleStatus(rootId);
	}

	// Now work through any children nodes
  	for(var n=0; n<this.hNodes[rootId].cNodes.length; n++) {
		if (this.hNodes[rootId].cNodes[n].hasChildren)
			this.openDescendants(this.hNodes[rootId].cNodes[n].id);
	}

};

// Finished
// Close all descendants of the specified node and the node itself
xTree.prototype.closeDescendants = function(rootId) {
	var root  = this.hNodes[rootId];

	// Work through any children nodes
	if (root.hasChildren && root.isOpen) {
		children = root.cNodes;
  		for(var n=0; n < children.length; n++) {
			this.closeDescendants(children[n].id);
		}
	}

	// Start with opening the root node if necessary
	if (root.isOpen) {
		this.toggleStatus(rootId);
	}

};

// Opens the tree to specified node
// nId is the id of the node to open the tree to
xTree.prototype.openTo = function(nId) {
	if (nId == "-1") return;

	var node = this.hNodes[nId];
	this.openTo(node.pid);
	if (node.isOpen) return;

	// Otherwise we have to find the closest open ancestor and start opening from there
	if (node.hasChildren)
		this.toggleStatus(nId);
};

// Closes all nodes on the same level as certain node
xTree.prototype.closeLevel = function(nodeId) {
	var node = this.hNodes[nodeId];
	var parent = this.hNodes[node.pid];
	for (var n=0; n<parent.cNodes.length; n++) {
		if (parent.cNodes[n].hasChildren) {
			this.closeDescendants(parent.cNodes[n].id);
		}
	}

	if (this.config.useCookies) this.storeStateOfNodes();

}

// Closes all nodes on the same level as certain node
xTree.prototype.collapseToChildren = function(nodeId) {
	var node = this.hNodes[nodeId];
	if (node.isOpen) {
		for (var n=0; n<node.cNodes.length; n++) {
			if (node.cNodes[n].hasChildren) {
				this.closeDescendants(node.cNodes[n].id);
			}
		}
	} else {
		this.toggleStatus(nodeId);
	}
	if (this.config.useCookies) this.storeStateOfNodes();

}

// Toggle Open or close status for a particular node
xTree.prototype.toggleStatus = function(id) {
	var cn = this.hNodes[id];
	this.setNodeStatus(!cn.isOpen, id, cn.lastSibling);
	cn.isOpen = !cn.isOpen;
	if (this.config.closeSameLevel) this.closeLevel(cn.id);
	if (this.config.useCookies) this.storeStateOfNodes();
};

// Set the status of a node (open or closed) affecting its visibility
// Status=false => closed and status=true => open
// id is the id of the node to adjust
// lastSibling is a boolean indicating if the node is the last sibling
// Only operates on nodes that have been rendered as HTML
// Only to be called from toggleStatus!!!!
xTree.prototype.setNodeStatus = function(status, id, lastSibling) {

	// eDiv is the div element containing the children of the node with the given id
	var eDiv = document.getElementById('d' + this.obj + id);
	this.current = eDiv;

	// eJoin is the img element containing the + or - for the node with the given id
	var eJoin = document.getElementById('j' + this.obj + id);

	// eIcon is the img element containing the icon for the node with the given id
	if (this.config.useIcons) {
		var eIcon = document.getElementById('i' + this.obj + id);
		eIcon.src = (status) ? this.hNodes[id].iconOpen : this.hNodes[id].icon;
	}

	eJoin.src = (this.config.useLines)? ((status)?((lastSibling)?this.icon.minusBottom:this.icon.minus):((lastSibling)?this.icon.plusBottom:this.icon.plus)): ((status)?this.icon.nlMinus:this.icon.nlPlus);

	// Change the display of the child elements
	if (status) {
		var anchor = document.getElementById('s' + this.obj + id);
		var node = this.hNodes[id];
		if (anchor) {
			anchor.className = "node " + node.diffStatus;
		}
		if (eDiv.hasChildNodes()) {
			eDiv.style.display = "block";
		}
		else
			this.addChildren(node);
	} else {
		eDiv.style.display = "none";
		var anchor = document.getElementById('s' + this.obj + id);
		var node = this.hNodes[id];
		if (anchor) {
			anchor.className = "node " + ((node.childModified == 'true' && node.hasChildren && node.diffStatus != 'removed') ? 'childModified ' : '') + node.diffStatus;
		}
	}
	this.hNodes[id]._isOpen = status;
};

// Finished
// [Cookie] Clears a cookie by making it expire and giving it a meaningless value
xTree.prototype.clearCookie = function() {
	var now = new Date();
	var yesterday = new Date(now.getTime() - 1000 * 60 * 60 * 24);
	this.setCookie('co' + this.obj, 'cookieValue', yesterday);
	this.setCookie('cs' + this.obj, 'cookieValue', yesterday);
};

// Finished
// [Cookie] Sets value in a cookie
xTree.prototype.setCookie = function(cookieName, cookieValue, expires, path, domain, secure) {
	var now = new Date();
	expires = expires || new Date(now.getTime() + 1000 * 60 * 60 * 24);
	document.cookie =
		escape(cookieName) + '=' + escape(cookieValue)
		+ (expires ? '; expires=' + expires.toGMTString() : '')
		+ (path ? '; path=' + path : '')
		+ (domain ? '; domain=' + domain : '')
		+ (secure ? '; secure' : '');
};

// Finished
// [Cookie] Gets a value from a cookie corresponding to the specified field name
xTree.prototype.getCookie = function(cookieName) {
	var cookieValue = '';
	var posName = document.cookie.indexOf(escape(cookieName) + '=');
	if (posName != -1) {
		var posValue = posName + (escape(cookieName) + '=').length;
		var endPos = document.cookie.indexOf(';', posValue);
		if (endPos != -1) cookieValue = unescape(document.cookie.substring(posValue, endPos));
		else cookieValue = unescape(document.cookie.substring(posValue));
	}
	return (cookieValue);
};


// TODO code up the storing of selected node IDs in the cookie
xTree.prototype.storeSelectedNodes = function () {
	var str = "";
	for (var i=0; i<this.sNodes.length; i++) {
		if (str) str += '.';
		str += this.sNodes[i];
	}
	this.setCookie('cs' + this.obj, str);
}


// [Cookie] Updates cookie to store the ids of open nodes as a string delimited by '.'
xTree.prototype.storeStateOfNodes = function() {
	var openNodes = [];
	openNodes = this.getStateOfNodes(openNodes,this.root);
	var str = "";
	for (var i=0; i<openNodes.length; i++) {
		if (str) str += '.';
		str += openNodes[i];
	}
	this.setCookie('co' + this.obj, str);
};

// Get the string specifying ids of all open nodes in the tree to store in the cookie
xTree.prototype.getStateOfNodes = function(openNodes,pNode) {
	for (var i=0; i<pNode.cNodes.length; i++) {
		if (pNode.cNodes[i].isOpen) {
			openNodes[openNodes.length] = pNode.cNodes[i].id;
		}
	}
	return openNodes;
};

// Tests if a node is open based on the content of the cookie
xTree.prototype.isOpen = function(id) {
	var aOpen = this.getCookie('co' + this.obj).split('.');
	for (var n=0; n<aOpen.length; n++) {
		if (aOpen[n] == id) {
			return true;
		}
	}
	return false;
};

// Tests if a node is selected based on the array of selected nodes in the tree instance
xTree.prototype.isSelected = function(id) {
	for (var n=0; n<this.sNodes.length; n++)
		if (this.sNodes[n] == id) return true;
	return false;
}

// Sets the array of selected nodes in the tree instance using the cookie
xTree.prototype.setSelectedNodes = function() {
	// Get the value of the cookie storing the state of the tree
	var selectedNodeIds = this.getCookie('cs' + this.obj).split('.');

	for (var n=0; n<selectedNodeIds.length; n++) {
		if (!selectedNodeIds[n] == "") {
			this.sNodes[this.sNodes.length] = selectedNodeIds[n];
		}
	}
};

// Finished
// If Push and pop is not implemented by the browser
if (!Array.prototype.push) {
	Array.prototype.push = function array_push() {
		for(var i=0;i<arguments.length;i++)
			this[this.length]=arguments[i];
		return this.length;
	}
};

if (!Array.prototype.pop) {
	Array.prototype.pop = function array_pop() {
		lastElement = this[this.length-1];
		this.length = Math.max(this.length-1,0);
		return lastElement;
	}
};

// Search handler for onclick operations
// Search for nodes matching the text argument using a global regular Expression
xTree.prototype.search = function(text,node) {

	// Global tracker for first matching node is firstMatchingNode
	if (node == null) {
		node = this.root;
		text.replace(/\s+/g," ");
		searchCriteria = text.split(" ");
		searchStrings = text.split(" ");
		omit = text.split(" ");
		for (var i=0; i<searchCriteria.length; i++) {
			omit[i] = /^\-/.test(searchCriteria[i]);
			searchStrings[i] = searchCriteria[i].replace(/^\-/,"");
			searchStrings[i] = searchStrings[i].replace(/[^\s\d\w]/,"");
			searchCriteria[i] = new RegExp(searchStrings[i],"i");
		}
  		this.deselectAllNodes();
		firstMatchingNode = null;
	}

	// Test the node name against the regular expression
	if (node.name) {
		var match = true;
		for (var j=0; j<searchCriteria.length; j++) {
			if (match == true)
				if (omit[j] == searchCriteria[j].test(node.name))
					match = false;
		}
		if (match) {
      			if(firstMatchingNode == null) {
          			firstMatchingNode = node;
      			}

      			this.openTo(node.id);
			this.selectNode(node.id);
		}
	}

	if (node.hasChildren)
  		for(var n=0; n < node.cNodes.length; n++)
			this.search(text,node.cNodes[n]);

  	if(node == this.root)
		if (firstMatchingNode != null)
      		this.jumpTo(firstMatchingNode.id);
  		else
    		alert("Search criteria are not met");
}

// Search for nodes matching the text argument using a global regular Expression
xTree.prototype.conceptSearch = function(text,node) {

	// Global tracker for first matching node is firstMatchingNode
	if (node == this.root) {
			text = text.replace(/^[^\w\d]+|[^\w\d]+$/g,"");
			regExp = new RegExp(text,"gi");
  		this.deselectAllNodes();
		firstMatchingNode = null;
	}

	// Test the node name against the regular expression
	if (node.name && regExp.test(node.name)) {
      		if(firstMatchingNode == null) {
          		firstMatchingNode = node;
      		}
      		this.openTo(node.id);
		this.selectNode(node.id);
    	}

	if (node.hasChildren)
  		for(var n=0; n < node.cNodes.length; n++)
			this.conceptSearch(text,node.cNodes[n]);

  	if(node == this.root)
		if (firstMatchingNode != null)
      			this.jumpTo(firstMatchingNode.id);
  		else
    			alert("This chosen concept is not part of the presentation tree.");
}

// Search for nodes matching the text argument using the detail page url
xTree.prototype.urlSearch = function(url,node) {

	var normURLs = /(\/[a-zA-Z\-0-9]+\/[a-zA-Z\-0-9]+)\.html/; // KLUDGE SHould use namespace:localname key!

	// Global tracker for first matching node is firstMatchingNode
	if (node == this.root) {
  		this.deselectAllNodes();
		firstMatchingNode = null;
		var results = url.match(normURLs);
		if (results == null) {
		  return;
		}
		url = results[1];
	}

	// Test the node name.
	var results = ("" + node.url).match(normURLs);
	if (results != null && results[1] == url) {
  		if (firstMatchingNode == null) {
      		firstMatchingNode = node;
  		}
  		this.openTo(node.id);
		this.selectNode(node.id);
    }

	if (node.hasChildren)
  		for(var n=0; n < node.cNodes.length; n++)
			this.urlSearch(url,node.cNodes[n]);

  	if(node == this.root)
		if (firstMatchingNode != null)
      		this.jumpTo(firstMatchingNode.id);

}

// If a detail page was loaded because of an action that
// other than the links in the tree, then the tree may be
// unsynchronised so synchronise it with a URL search.
xTree.prototype.synchronise = function(urlToFind) {
	if (this.synchronised) {
		this.synchronised = false;
		return;
	} else {
		this.urlSearch(urlToFind,this.root);
	}
};

// Jump to a specific node in the tree
xTree.prototype.jumpTo = function(id) {
	var div = document.getElementById("s" + this.obj + id);
	window.scrollTo(0, div.offsetTop - document.body.clientHeight / 2);
};

// Deselect all nodes in the tree
xTree.prototype.deselectAllNodes = function() {
	// Iterate the list of selected nodes in the tree instance
	for(var n=0; n<this.sNodes.length; n++) {
		var e = document.getElementById("s" + this.obj + this.sNodes[n]);
		if (e) {
			var node = this.hNodes[this.sNodes[n]];
			e.className = "node " + ((node.childModified == 'true' && node.hasChildren && !node.isOpen && node.diffStatus != 'removed') ? 'childModified ' : '') + node.diffStatus;
		}
	}
	this.sNodes = [];
}
